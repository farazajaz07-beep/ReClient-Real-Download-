# ReClient — feature update (Minecraft 1.21 / Fabric)

This is a source project update based on ReClient 1.0.0.

## Included in this update
- Crosshair Indicator module, enabled by default, with Crosshair Size and Crosshair Gap settings.
- New PvP category in the Right Shift menu.
- Settings scaffolding for Motion Blur (Experimental), No Overlays, and Crystal Optimizer.
- Existing HUD, theme, zoom, and config persistence retained.

## Important status notes
- Crosshair Indicator is implemented in this update.
- Motion Blur is not a true full-screen motion-blur shader yet; it is marked experimental and its setting is preparatory only.
- No Overlays currently exposes the intended toggles, but fire/shield/totem suppression is not hooked into Minecraft rendering yet.
- Crystal Optimizer currently exposes the feature module and particle option, but does not yet alter crystal rendering/particles. No gameplay or damage behavior is modified.
- This source archive has not been compiled in this environment because the Gradle wrapper distribution could not be downloaded (network DNS unavailable). Build and test before installing.

## Build
Use Java 21 (Minecraft 1.21 Fabric requires Java 21):

```bash
chmod +x gradlew
./gradlew build
```

The installable mod, if build succeeds, is `build/libs/reclient-1.0.0.jar`. Do not install the `-sources.jar`.

## Install on Zalith Launcher
1. Build the project in GitHub Codespaces or another computer with internet access and Java 21.
2. Open the repository's `ReClient/build/libs/` directory and download `reclient-1.0.0.jar`.
3. In Zalith, open the Minecraft 1.21 Fabric instance's `mods` folder and copy the JAR there.
4. Keep Fabric Loader and Fabric API compatible with Minecraft 1.21. Start once and check the log if it fails.
5. Press Right Shift in-game to open the ReClient menu.

If the game crashes, remove the new JAR and share `latestlog.txt`.
