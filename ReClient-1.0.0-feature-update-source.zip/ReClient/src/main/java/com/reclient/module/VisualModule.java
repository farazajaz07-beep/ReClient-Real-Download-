package com.reclient.module;

import com.reclient.setting.BoolSetting;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;

/** Small visual modules whose controls are persisted by ReConfig. */
public final class VisualModule extends Module {
    public enum Kind { CROSSHAIR, MOTION_BLUR, NO_OVERLAYS, CRYSTAL_OPTIMIZER }
    public final Kind kind;
    public final BoolSetting showHitMarker;
    public final SliderSetting crosshairSize;
    public final SliderSetting crosshairGap;
    public final SliderSetting blurStrength;
    public final BoolSetting hideFire;
    public final BoolSetting hideShield;
    public final BoolSetting hideTotem;
    public final BoolSetting reduceParticles;

    public VisualModule(Kind kind) {
        super(switch (kind) {
            case CROSSHAIR -> "Crosshair Indicator";
            case MOTION_BLUR -> "Motion Blur (Experimental)";
            case NO_OVERLAYS -> "No Overlays";
            case CRYSTAL_OPTIMIZER -> "Crystal Optimizer";
        }, switch (kind) {
            case CROSSHAIR -> "Draw a customizable crosshair indicator.";
            case MOTION_BLUR -> "Experimental lightweight motion-trail setting; full-screen blur needs shader support.";
            case NO_OVERLAYS -> "Toggle fire, shield and totem visual suppression options.";
            case CRYSTAL_OPTIMIZER -> "Reduce particles for a lighter crystal PvP scene.";
        }, kind == Kind.CROSSHAIR || kind == Kind.MOTION_BLUR ? Category.HUD : Category.PVP);
        this.kind = kind;
        showHitMarker = bool("Hit Marker", true);
        crosshairSize = slider("Crosshair Size", 5, 2, 12, 1);
        crosshairGap = slider("Crosshair Gap", 3, 0, 8, 1);
        blurStrength = slider("Trail Strength", 2, 1, 5, 1);
        hideFire = bool("Hide Fire Overlay", true);
        hideShield = bool("Hide Shield Animation", true);
        hideTotem = bool("Hide Totem Pop", true);
        reduceParticles = bool("Reduce Particles", true);
        // Only the crosshair is enabled by default. Other effects are opt-in.
        enabled = kind == Kind.CROSSHAIR;
    }

    public void render(GuiGraphics g, Minecraft mc) {
        if (!enabled || kind != Kind.CROSSHAIR || mc.player == null || mc.options.hideGui || mc.screen != null) return;
        int cx = mc.getWindow().getGuiScaledWidth() / 2;
        int cy = mc.getWindow().getGuiScaledHeight() / 2;
        int s = crosshairSize.asInt();
        int gap = crosshairGap.asInt();
        int color = 0xFF42F5B3;
        // Four clean arms, leaving a gap in the center.
        g.fill(cx - s, cy - 1, cx - gap, cy + 1, color);
        g.fill(cx + gap, cy - 1, cx + s, cy + 1, color);
        g.fill(cx - 1, cy - s, cx + 1, cy - gap, color);
        g.fill(cx - 1, cy + gap, cx + 1, cy + s, color);
    }
}
