package com.reclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Client-side night vision so caves and nights are fully lit. */
public class FullbrightModule extends Module {
	private boolean applied;

	public FullbrightModule() {
		super("Fullbright", "See clearly in caves and at night.", Category.UTILITY);
	}

	@Override
	public void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null) return;
		MobEffectInstance current = p.getEffect(MobEffects.NIGHT_VISION);
		if (current == null || current.getDuration() < 600) {
			p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, false, false, false));
			applied = true;
		}
	}

	@Override
	public void onDisable() {
		LocalPlayer p = Minecraft.getInstance().player;
		if (p != null && applied) p.removeEffect(MobEffects.NIGHT_VISION);
		applied = false;
	}
}
