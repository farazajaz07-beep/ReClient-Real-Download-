package com.reclient;

import com.mojang.blaze3d.platform.InputConstants;
import com.reclient.module.ModuleManager;
import com.reclient.ui.ReScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("ReClient");

	public static KeyMapping menuKey;
	public static KeyMapping zoomKey;

	@Override
	public void onInitializeClient() {
		menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.reclient.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.reclient"));
		zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.reclient.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.reclient"));

		ModuleManager.init();
		ReConfig.load();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (menuKey.consumeClick()) {
				if (mc.screen == null) mc.setScreen(new ReScreen());
			}
			ModuleManager.tick(mc);
		});

		// once per rendered world frame: FPS/CPS stats + smooth effects like zoom
		WorldRenderEvents.START.register(ctx -> ModuleManager.frame(net.minecraft.client.Minecraft.getInstance()));

		HudRenderCallback.EVENT.register((graphics, tickDelta) -> ModuleManager.renderHud(graphics));

		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
			if (ModuleManager.zoom != null) ModuleManager.zoom.restore(mc);
			ReConfig.save();
		});

		LOGGER.info("ReClient loaded. Press Right Shift in-game to open the menu.");
	}
}
