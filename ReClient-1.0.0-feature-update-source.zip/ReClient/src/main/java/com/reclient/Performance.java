package com.reclient;

import com.google.gson.JsonObject;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;

/** One-click FPS presets built on vanilla video options, with a backup so you can always go back. */
public final class Performance {
	public record Preset(String name, String blurb, int renderDistance, int simDistance, GraphicsStatus graphics,
			ParticleStatus particles, CloudStatus clouds, boolean ambientOcclusion, double entityDistance,
			int biomeBlend, boolean entityShadows, boolean vsync, int fpsLimit) {}

	public static final Preset[] PRESETS = {
		new Preset("Potato", "Maximum FPS. Minimal visuals.", 6, 5, GraphicsStatus.FAST, ParticleStatus.MINIMAL,
				CloudStatus.OFF, false, 0.5, 0, false, false, 260),
		new Preset("Balanced", "Smooth and still good looking.", 10, 8, GraphicsStatus.FAST, ParticleStatus.DECREASED,
				CloudStatus.FAST, false, 0.75, 1, false, false, 260),
		new Preset("Quality", "Prettier. Needs a decent PC.", 16, 12, GraphicsStatus.FANCY, ParticleStatus.ALL,
				CloudStatus.FANCY, true, 1.0, 2, true, false, 260),
	};

	public static String active = "";
	private static JsonObject backup;

	private Performance() {}

	public static boolean hasBackup() {
		return backup != null;
	}

	public static void apply(Minecraft mc, Preset p) {
		Options o = mc.options;
		if (backup == null) backup = snapshot(o);
		o.renderDistance().set(p.renderDistance());
		o.simulationDistance().set(p.simDistance());
		o.graphicsMode().set(p.graphics());
		o.particles().set(p.particles());
		o.cloudStatus().set(p.clouds());
		o.ambientOcclusion().set(p.ambientOcclusion());
		o.entityDistanceScaling().set(p.entityDistance());
		o.biomeBlendRadius().set(p.biomeBlend());
		o.entityShadows().set(p.entityShadows());
		o.enableVsync().set(p.vsync());
		o.framerateLimit().set(p.fpsLimit());
		o.save();
		active = p.name();
		ReConfig.save();
	}

	public static boolean restore(Minecraft mc) {
		if (backup == null) return false;
		Options o = mc.options;
		try {
			o.renderDistance().set(backup.get("renderDistance").getAsInt());
			o.simulationDistance().set(backup.get("simDistance").getAsInt());
			o.graphicsMode().set(GraphicsStatus.valueOf(backup.get("graphics").getAsString()));
			o.particles().set(ParticleStatus.valueOf(backup.get("particles").getAsString()));
			o.cloudStatus().set(CloudStatus.valueOf(backup.get("clouds").getAsString()));
			o.ambientOcclusion().set(backup.get("ao").getAsBoolean());
			o.entityDistanceScaling().set(backup.get("entityDistance").getAsDouble());
			o.biomeBlendRadius().set(backup.get("biomeBlend").getAsInt());
			o.entityShadows().set(backup.get("entityShadows").getAsBoolean());
			o.enableVsync().set(backup.get("vsync").getAsBoolean());
			o.framerateLimit().set(backup.get("fpsLimit").getAsInt());
			o.save();
		} catch (Exception e) {
			ReClient.LOGGER.warn("Could not fully restore the video settings backup", e);
		}
		backup = null;
		active = "";
		ReConfig.save();
		return true;
	}

	private static JsonObject snapshot(Options o) {
		JsonObject j = new JsonObject();
		j.addProperty("renderDistance", o.renderDistance().get());
		j.addProperty("simDistance", o.simulationDistance().get());
		j.addProperty("graphics", o.graphicsMode().get().name());
		j.addProperty("particles", o.particles().get().name());
		j.addProperty("clouds", o.cloudStatus().get().name());
		j.addProperty("ao", o.ambientOcclusion().get());
		j.addProperty("entityDistance", o.entityDistanceScaling().get());
		j.addProperty("biomeBlend", o.biomeBlendRadius().get());
		j.addProperty("entityShadows", o.entityShadows().get());
		j.addProperty("vsync", o.enableVsync().get());
		j.addProperty("fpsLimit", o.framerateLimit().get());
		return j;
	}

	public static JsonObject toJson() {
		JsonObject j = new JsonObject();
		j.addProperty("active", active);
		if (backup != null) j.add("backup", backup);
		return j;
	}

	public static void fromJson(JsonObject j) {
		if (j == null) return;
		if (j.has("active")) active = j.get("active").getAsString();
		if (j.has("backup") && j.get("backup").isJsonObject()) backup = j.getAsJsonObject("backup");
	}
}
